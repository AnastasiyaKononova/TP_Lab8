#import "Record.h"


@implementation Record

@dynamic aviaCompany;
@dynamic cityFrom;
@dynamic cityTo;
@dynamic price;

@end
