#import <UIKit/UIKit.h>

@interface FlightsController : UIViewController

- (id)initWithCityFrom: (NSString*)cityFrom withCityTo: (NSString*)cityTo;

@end
